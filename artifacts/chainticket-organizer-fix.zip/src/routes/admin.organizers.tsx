import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { useSession } from "@/components/session";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fetchOrganizers, patchOrganizer, saveOrganizer } from "@/lib/api";
import type { OrganizerRow } from "@/lib/types";
import { shortAddr } from "@/lib/utils";

export const Route = createFileRoute("/admin/organizers")({ component: OrganizersPage });

function OrganizersPage() {
  const { me } = useSession();
  const [rows, setRows] = useState<OrganizerRow[]>([]);
  const [wallet, setWallet] = useState(me?.address ?? "");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [listError, setListError] = useState<string | null>(null);

  async function reload() {
    setLoading(true);
    setListError(null);
    try {
      setRows(await fetchOrganizers());
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to load organizers";
      setListError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (me?.isAdmin) void reload();
  }, [me?.isAdmin]);

  useEffect(() => {
    if (me?.address && !wallet) setWallet(me.address);
  }, [me?.address, wallet]);

  if (!me?.isAdmin) {
    return (
      <AppShell>
        <p className="text-sm text-muted">Admin only. Open Admin first and initialize this wallet.</p>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <h1 className="font-display text-4xl italic">Verified organizers</h1>
      <p className="mt-1 text-sm text-muted">Whitelist wallets that may mint events and scan gates.</p>
      <Card className="mt-6 max-w-xl p-5">
        <div className="grid gap-3">
          <div className="grid gap-1.5">
            <Label>Organizer wallet</Label>
            <Input
              value={wallet}
              onChange={(e) => setWallet(e.target.value)}
              placeholder="0x…"
            />
          </div>
          <div className="grid gap-1.5">
            <Label>Label / name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Venue co." />
          </div>
          <Button
            type="button"
            onClick={async () => {
              try {
                await saveOrganizer({ data: { wallet, name } });
                toast.success("Organizer approved");
                setName("");
                await reload();
              } catch (e) {
                toast.error(e instanceof Error ? e.message : "Failed");
              }
            }}
          >
            Verify & add
          </Button>
        </div>
      </Card>
      {listError ? <p className="mt-4 text-sm text-danger">{listError}</p> : null}
      <div className="mt-6 divide-y divide-border rounded-xl border border-border">
        {loading && rows.length === 0 ? (
          <p className="px-4 py-6 text-sm text-muted">Loading from vault database…</p>
        ) : null}
        {!loading && rows.length === 0 && !listError ? (
          <p className="px-4 py-6 text-sm text-muted">
            No organizers yet. Add your wallet above to mint.
          </p>
        ) : null}
        {rows.map((row) => (
          <div
            key={row.wallet}
            className="flex flex-wrap items-center justify-between gap-3 px-4 py-3"
          >
            <div>
              <p className="font-medium">{row.name}</p>
              <p className="font-mono text-xs text-muted">{shortAddr(row.wallet)}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={row.status === "approved" ? "sage" : "danger"}>{row.status}</Badge>
              <span className="text-xs text-muted">{row.eventCount} events</span>
              {row.status === "approved" ? (
                <Button
                  size="sm"
                  variant="outline"
                  type="button"
                  onClick={async () => {
                    try {
                      await patchOrganizer({ data: { wallet: row.wallet, status: "revoked" } });
                      await reload();
                    } catch (e) {
                      toast.error(e instanceof Error ? e.message : "Failed");
                    }
                  }}
                >
                  Revoke
                </Button>
              ) : (
                <Button
                  size="sm"
                  type="button"
                  onClick={async () => {
                    try {
                      await patchOrganizer({ data: { wallet: row.wallet, status: "approved" } });
                      await reload();
                    } catch (e) {
                      toast.error(e instanceof Error ? e.message : "Failed");
                    }
                  }}
                >
                  Approve
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
