import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { useSession } from "@/components/session";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fetchRoyalty, initAdmin, saveRoyalty } from "@/lib/api";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const { me, refresh } = useSession();
  const navigate = useNavigate();
  const [adminCount, setAdminCount] = useState<number | null>(null);
  const [bps, setBps] = useState("10");
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    void fetchRoyalty()
      .then((r) => {
        setAdminCount(r.adminCount);
        setBps(String(r.royaltyBps / 100));
        setLoadError(null);
      })
      .catch((e) => {
        setLoadError(e instanceof Error ? e.message : "Could not reach vault ledger");
      });
  }, []);

  if (!me) {
    return (
      <AppShell>
        <p className="text-sm text-muted">Connect a wallet.</p>
      </AppShell>
    );
  }

  if (!me.isAdmin) {
    return (
      <AppShell>
        <h1 className="font-display text-4xl italic">Admin</h1>
        {loadError ? (
          <Card className="mt-6 max-w-lg p-5">
            <p className="text-sm text-danger">Vault ledger error: {loadError}</p>
            <p className="mt-2 text-xs text-muted">
              Database is required for admin bootstrap. Restart the app so PGLite/Neon can migrate.
            </p>
          </Card>
        ) : adminCount === 0 ? (
          <Card className="mt-6 max-w-lg p-5">
            <p className="text-sm">
              No admin is initialized. The first wallet can claim the admin key and then whitelist
              organizers.
            </p>
            <Button
              className="mt-4"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  await initAdmin();
                  await refresh();
                  toast.success("You are the admin");
                } catch (e) {
                  toast.error(e instanceof Error ? e.message : "Failed");
                } finally {
                  setBusy(false);
                }
              }}
            >
              Initialize this wallet as admin
            </Button>
          </Card>
        ) : adminCount === null ? (
          <p className="mt-3 text-sm text-muted">Loading admin status…</p>
        ) : (
          <p className="mt-3 text-sm text-muted">This wallet is not an admin.</p>
        )}
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-display text-4xl italic">Admin</h1>
        <Button
          variant="outline"
          type="button"
          onClick={() => {
            void navigate({ to: "/admin/organizers" });
          }}
        >
          Organizer list
        </Button>
      </div>
      <Card className="mt-6 max-w-lg p-5">
        <Label>Secondary royalty (%)</Label>
        <p className="mt-1 text-xs text-muted">Deducted from the seller on every resale.</p>
        <div className="mt-3 flex gap-2">
          <Input value={bps} onChange={(e) => setBps(e.target.value)} />
          <Button
            onClick={async () => {
              try {
                await saveRoyalty({ data: { bps: Math.round(Number(bps) * 100) } });
                toast.success("Royalty updated");
              } catch (e) {
                toast.error(e instanceof Error ? e.message : "Failed");
              }
            }}
          >
            Update royalty
          </Button>
        </div>
      </Card>
      <Card className="mt-4 max-w-lg p-5">
        <p className="text-sm font-medium">Data layer (Web2.5)</p>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted">
          <li>
            <strong className="text-fg">Database:</strong> events, tickets, vault balances, KYC, and
            organizer whitelist live in Postgres (PGLite in preview, Neon when DATABASE_URL is set).
          </li>
          <li>
            <strong className="text-fg">Chain:</strong> wallet identity on Gnosis Chiado. Settlement
            follows the vault rules in the server ledger (same 90–110% / royalty / refund rules as
            the Solidity contracts in <code className="text-xs">contracts/</code>).
          </li>
        </ul>
      </Card>
    </AppShell>
  );
}
